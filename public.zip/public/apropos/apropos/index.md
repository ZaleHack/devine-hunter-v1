# A propos


<style>
  body {
    text-align: justify;
  }
  /* Ajoutez d'autres styles selon vos besoins */
</style>

## Presentation 

Salut, je suis Saliou Thiam, un passionné de la sécurité informatique et je suis spécialisé dans le Pentest. Mon expertise réside dans la découverte proactive de vulnérabilités pour renforcer la sécurité des systèmes informatiques.

## Certifications 

- 🛡️ Certified Ethical Hacker
- 🔐 ComptiaSec+
- 🌐 Google CyberSecurity Certificat Professional
- 🌐 Threat Intelligence and Risk Monitoring 
- 🔐 API Penetration Testing

## Contact

<em><strong>📧 Email : info@zalepentester.com</strong></em>

